Obrigado por usar ImageToStl. Junto com esta nota, você encontrará o(s) arquivo(s) convertido(s).

Visite ImageToStl em https://imagetostl.com para obter mais ferramentas gratuitas de conversão de arquivos e visualização on-line.